package com.ldz.socket.common.bean;

import lombok.Getter;
import lombok.Setter;

// 终端注册 bean
@Setter
@Getter
public class TerminalRegMsg {

    private String province;  // 省

    private String city; // 市

    private String provider; // 制造商

    private String deviceType; // 终端型号  由制造商自行定义

    private String terminalId; // 终端Id 由制造商自行定义

    private String color; // 车辆颜色

    private String plateNum;  // 车牌号
}
