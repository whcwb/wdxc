package com.ldz.socket.common.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ZdSetBean {

    // 终端编号
    private String deviceId;
    // 主服务器 IP
    private String ip;
    // 副服务器ip
    private String ip1;
    // 端口
    private String dk;
    // 定时汇报
    private String dshb;
    // 位置汇报方案
    private String wzhbfa;
    // 缺省时间间隔
    private String sjjg;
    // 软件终端版本号
    private String bbh;
}
