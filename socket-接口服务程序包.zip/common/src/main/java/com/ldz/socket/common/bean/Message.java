package com.ldz.socket.common.bean;



import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ldz.socket.common.constant.CommandCode;
import com.ldz.socket.common.command.BaseCommand;
import com.ldz.socket.common.util.CommandUtil;
import lombok.Getter;
import lombok.Setter;

import io.netty.channel.Channel;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Message {
    private int code; // 命令码
    private String command; // 消息体
    private String checkCode; // 校验码
    private int flowId; // 流水号
    private String deviceId; // 终端编号
    @JsonIgnore
    private Channel channel;
    private String authCode;
    public Message(){

    }

    public Message(BaseCommand command){
        this.code = command.getCommandCode().getCode();
        System.out.println(this.code);
        this.command = JsonUtil.toJson(command);
        this.deviceId = command.getDeviceId();
    }


    public void fill(){
        this.flowId = CommandUtil.INSTANCE.getFlowId();
    }
}
