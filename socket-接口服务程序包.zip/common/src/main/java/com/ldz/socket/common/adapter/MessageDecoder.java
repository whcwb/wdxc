package com.ldz.socket.common.adapter;


import com.ldz.socket.common.bean.JsonUtil;
import com.ldz.socket.common.bean.Message;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufUtil;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.DelimiterBasedFrameDecoder;
import lombok.extern.slf4j.Slf4j;


/**
 * 数据解码器，将接收到的字节数据，按照协议格式封装成bean结构
 *
 */
public class MessageDecoder extends DelimiterBasedFrameDecoder {

	public MessageDecoder(int maxFrameLength, ByteBuf... delimiters) {
		super(maxFrameLength, delimiters);
	}

    @Override
    protected Object decode(ChannelHandlerContext ctx, ByteBuf in) {
		int length = in.readableBytes();
		ByteBuf dataBuf = in.readBytes(length);

		try{
			String data = new String(ByteBufUtil.getBytes(dataBuf), "UTF-8");
			System.out.println("接收数据:"+data);
			Message message = JsonUtil.toBean(data, Message.class);
			if (message == null) return null;
			return message;
		}catch (Exception e){
			e.printStackTrace();
		}
		return null;
    }

}
