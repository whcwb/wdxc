package com.ldz.socket.common.constant;

public enum MessageConfig {

    INSTANCE;

    private String head = "(";
    private String tail = ")";

    public String getHead() {
        return head;
    }

    public String getTail() {
        return tail;
    }
}
