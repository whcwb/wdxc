package com.ldz.socket.common.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LocationInfo {
    /**
     *  报警标志
     */
    private String eventType;
    /**
     *  状态
     */
    private int statusField;

    /**
     *  经度
     */
    private String latitude;

    /**
     * 纬度
     */
    private String longitude;

    /**
     *  海拔高度
     */
    private String elevation;

    /**
     *  速度
     */
    private String speed;

    /**
     * 方向
     */
    private String direction;

    /**
     * 时间
     */
    private String time;
    /**
     * 卫星个数
     */
    private String starNum;
}
