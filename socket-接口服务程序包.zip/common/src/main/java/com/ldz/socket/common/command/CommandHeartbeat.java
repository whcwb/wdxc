package com.ldz.socket.common.command;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ldz.socket.common.constant.CommandCode;

public class CommandHeartbeat extends BaseCommand {
    public CommandHeartbeat(String deviceId) {
        super(deviceId);
    }

    public CommandHeartbeat(){}
    @Override
    @JsonIgnore
    public CommandCode getCommandCode(){
        return CommandCode.HEARTBEAT;
    }
}
