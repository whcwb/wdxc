package com.ldz.socket.common.command;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ldz.socket.common.constant.CommandCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
@ToString
public class CommandBatchGps extends BaseCommand implements Serializable {
    private List<CommandGps> gpsList;
    public CommandBatchGps(){}
    public CommandBatchGps(String deviceId) {
        super(deviceId);
    }

    @Override
    @JsonIgnore
    public CommandCode getCommandCode(){
        return CommandCode.BATCH_GPS;
    }
}
