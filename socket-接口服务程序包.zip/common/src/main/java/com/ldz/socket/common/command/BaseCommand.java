package com.ldz.socket.common.command;


import com.ldz.socket.common.constant.CommandCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaseCommand {
    private String deviceId;

    public BaseCommand(){}

    public BaseCommand(String deviceId) {
        this.deviceId = deviceId;
    }


    public CommandCode getCommandCode(){
        return null;
    }


}
