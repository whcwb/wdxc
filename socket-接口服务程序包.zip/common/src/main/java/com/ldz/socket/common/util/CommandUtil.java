package com.ldz.socket.common.util;

import com.ldz.socket.common.bean.JsonUtil;
import com.ldz.socket.common.bean.Message;
import com.ldz.socket.common.constant.MessageConfig;
import com.ldz.socket.common.exception.RuntimeCheck;

import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;

public enum CommandUtil {
    INSTANCE;

    private int flowId;

    public int getFlowId(){
        return flowId ++;
    }


    public void sendMessage(Channel channel, Message message){
        RuntimeCheck.ifNull(channel,"未找到通道");
        message.fill();
        String m = MessageConfig.INSTANCE.getHead()+ JsonUtil.toJson(message) + MessageConfig.INSTANCE.getTail();
        try {
			channel.writeAndFlush(Unpooled.copiedBuffer(m.getBytes("UTF-8")));
			
		} catch (Exception e) {
		}
    }
}
