package com.ldz.socket.common.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CommonRespMsg {

    private int replyFlowId; // 应答流水号

    private int replyId; // 应答Id

    private byte replyCode; // 应答结果

    private String code;

    private String flowId;

    private String deviceId;

    private int checkCode;

    private String command;

    private String authCode;
}
