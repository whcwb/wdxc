package com.ldz.socket.common.command;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ldz.socket.common.constant.CommandCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@ToString
public class CommandGps extends BaseCommand implements Serializable {
    public CommandGps(){
    }
    public CommandGps(String deviceId) {
        super(deviceId);
    }

    @Override
    @JsonIgnore
    public CommandCode getCommandCode(){
        return CommandCode.GPS;
    }
    /**
     *  报警标志
     */
    private String eventType;
    /**
     *  状态
     */
    private int statusField;

    /**
     *  经度
     */
    private String latitude;

    /**
     * 纬度
     */
    private String longitude;

    /**
     *  海拔高度
     */
    private String elevation;

    /**
     *  速度
     */
    private String speed;

    /**
     * 方向
     */
    private String direction;

    /**
     * 时间
     */
    private String time;
    /**
     * 卫星个数
     */
    private String starNum;
}
