package com.ldz.socket.common.constant;

public enum  SettingType {
    TAKE_PHOTO("1","takePhoto"),
    TAKE_VIDEO("2","takeVideo"),
    SET_URL("3","setUrl"), // 设置接口地址
    UPDATE("4","update"), // 版本升级
    SET_UPLOAD_DURATION("5","setUploadDuration"), // 设置上传间隔
    SET_UPLOAD_DMODE("6","setUploadMode"), // 设置上传模式
    ;

    private String code;
    private String name;

    public static SettingType toEnum(String code){
        for (SettingType value : SettingType.values()) {
            if (code.equals(value.code))return value;
        }
        return null;
    }

    SettingType(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }
}
