package com.ldz.socket.common.constant;

public enum CommandCode {
    HEARTBEAT(2,"Heartbeat"),
    SETTING(10,"Setting"),
    GPS(12,"Gps"),
    BATCH_GPS(13,"BatchGps"),
    ;

    CommandCode(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public static CommandCode toEnum(int code){
        for (CommandCode value : CommandCode.values()) {
            if (value.code == code){
                return value;
            }
        }
        return null;
    }

    private int code;
    private String name;

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }
}
