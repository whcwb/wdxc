package com.ldz.socket.common.command;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ldz.socket.common.constant.CommandCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CommandSetting extends BaseCommand {
    private String type;
    private String param;
    public CommandSetting(){}
    public CommandSetting(String deviceId) {
        super(deviceId);
    }

    @Override
    @JsonIgnore
    public CommandCode getCommandCode(){
        return CommandCode.SETTING;
    }
}
