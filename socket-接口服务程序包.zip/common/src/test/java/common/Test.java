package common;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.comparator.LastModifiedFileComparator;

public class Test {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub

		//F20181225132124.ts
		//FCP20190211145450.mp4
		//2018-12-25 13:21:24
		//2019-02-11 14:54:50
		String fileName = "F20181225132124.ts";
		String subfix = fileName.substring(fileName.indexOf(".")+1);
		fileName = fileName.substring(0, fileName.indexOf("."));
		
		final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		//System.out.println(subfix+"==="+fileName.replaceAll("\\d", "")+"==="+sdf.parse(fileName.replaceAll("[a-zA-Z]", "")));
		String stopHours = "23-06";
		
		File f = new File("d:/JT-808运管协议.zip");
		System.out.println((f.length() / 1024 / 1024));
		if (!"-1".equals(stopHours)){
            String[] houres = stopHours.split("-");
            int curHHInt = Integer.parseInt("22");
            if (curHHInt >= Integer.parseInt(houres[0]) || curHHInt < Integer.parseInt(houres[1])){
            	System.out.println("停止时间段范围内");
            }else{
            	System.out.println("联网时间");
            }
        }
	}

}
