package com.ldz.server;

import java.io.IOException;
import java.util.Map;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ldz.socket.common.bean.Message;

public class Test {
	
	public static String wdZdbhs = "865923030004276,865923030006057,865923030006602,865923030008467,865923030008533,865923030008541,865923030008558,865923030008830,865923030009275,865923030009978,865923030010018,865923030010034,865923030010042,865923030010141,865923030010158,865923030010174,865923030010190,865923030010265,865923030010273,865923030011313,865923030017658,865923030017781,865923030017807,865923030017849,865923030017864,865923030018029,865923030018177,865923030018219,865923030028440,865923030028499,865923030028994,865923030029000,865923030034802,865923030033481,865923030034299,865923030034703,865923030034885,865923030035015,865923030035031,865923030035114,865923030035205,865923030035270,865923030035288,865923030035395,865923030035494,865923030035650,865923030038498,865923030038662,865923030038837,865923030038845,865923030039058,865923030039413,865923030067588,865923030067596,865923030068024,865923030068057,865923030068198";

	public static void main(String[] args) throws JsonParseException, JsonMappingException, IOException{
		String json = "{\"authCode\":null,\"checkCode\":null,\"code\":2,\"command\":\"{\\\"versionCode\\\":2002,\\\"versionName\\\":\\\"2.0.2\\\"}\",\"deviceId\":\"865923030034703\",\"flowId\":0}";
		ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		if (wdZdbhs.contains("865923030038662")){
			Message bean = mapper.readValue(json, Message.class);
			Map versionMap = mapper.readValue(bean.getCommand(), Map.class);
			System.out.println("终端存在:"+versionMap.get("versionCode"));
		}
	}
}
