package com.ldz.server.handler.biz;

import com.ldz.server.jt808.vo.PackageData;
import com.ldz.server.jt808.vo.req.TravelData;
import com.ldz.server.util.RedisTemplateUtil;
import com.ldz.socket.common.bean.JsonUtil;
import io.netty.channel.ChannelHandlerContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 行程数据包：
 * // 7E 02 00 00 26 12 34 56 78 90 12 00 7D 02 00 00 00 01 00 00 00 02 00 BA 7F 0E 07 E4 F1 1C 00 28 00 3C 00 00 18 10 15 10 10 10 01 04 00 00 00 64 02 02 00 7D 01 13 7E
 *
 // 3. 行程信息汇报 ==> 平台通用应答
 */
@Component
public class BizHandler515 extends BizBaseHandler {
    @Autowired
    private RedisTemplateUtil redisTemplate;

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        PackageData packageData = (PackageData) msg;
        final PackageData.MsgHeader header = packageData.getMsgHeader();
        accessLog.info(">>>>>[行程数据包],phone={},flowid={}", header.getTerminalPhone(), header.getFlowId());
        try {
            TravelData travelData = this.msgDecoder.toTravelDataReq(packageData);
            redisTemplate.opsForList().leftPushAll("travelData", travelData);
            accessLog.info("save travelData to redis");
            redisTemplate.convertAndSend("travelData", JsonUtil.toJson(travelData));
//            accessLog.debug("行程数据包:{}", JSON.toJSONString(travelData, true));
        } catch (Exception e) {
            errorLog.error("<<<<<[行程数据包]处理错误,phone={},flowid={},err={}", header.getTerminalPhone(), header.getFlowId(), e.getMessage());
            e.printStackTrace();
        }
    }
}
