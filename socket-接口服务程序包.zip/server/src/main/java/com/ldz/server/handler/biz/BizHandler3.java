package com.ldz.server.handler.biz;

import com.ldz.server.jt808.vo.PackageData;
import com.ldz.server.jt808.vo.resp.ServerCommonRespMsgBody;
import com.ldz.socket.common.bean.Message;
import io.netty.channel.ChannelHandlerContext;
import org.springframework.stereotype.Component;

/**
 *
 // 7. 终端注销(终端注销数据消息体为空) ==> 平台通用应答
 */
@Component
public class BizHandler3 extends BizBaseHandler {
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        Message message = (Message) msg;
//        final PackageData.MsgHeader header = packageData.getMsgHeader();
        accessLog.info(">>>>>[终端注销],phone={},flowid={}", message.getDeviceId(), message.getFlowId());
        try {
            // final PackageData.MsgHeader reqHeader = packageData.getMsgHeader();
            ServerCommonRespMsgBody respMsgBody = new ServerCommonRespMsgBody(message.getFlowId(), message.getCode(), ServerCommonRespMsgBody.success);
            int flowId = super.getFlowId(message.getChannel());
//            String bs = messageEncoder.encode4ServerCommonRespMsg(message, respMsgBody, flowId);
//            super.send2Client(ctx.channel(), bs);
            accessLog.info("<<<<<[终端注销],phone={},flowid={}", message.getDeviceId(), message.getFlowId());
        } catch (Exception e) {
            errorLog.error("<<<<<[终端注销]处理错误,phone={},flowid={},err={}",  message.getDeviceId(), message.getFlowId(), e.getMessage());
            e.printStackTrace();
        }
    }
}
