package com.ldz.server.handler.biz;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ldz.server.bean.RequestCommonParamsDto;
import com.ldz.server.jt808.vo.PackageData;
import com.ldz.server.jt808.vo.resp.ServerCommonRespMsgBody;
import com.ldz.server.util.HttpUtil;
import com.ldz.socket.common.bean.Message;
import io.netty.channel.ChannelHandlerContext;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

/**
 *
 // 1. 终端心跳-消息体为空 ==> 平台通用应答
 */
@Component
public class BizHandler2  extends BizBaseHandler {
	
	private String wdZdbhs = "865923030004276,865923030006057,865923030006602,865923030008467,865923030008533,865923030008541,865923030008558,865923030008830,865923030009275,865923030009978,865923030010018,865923030010034,865923030010042,865923030010141,865923030010158,865923030010174,865923030010190,865923030010265,865923030010273,865923030011313,865923030017658,865923030017781,865923030017807,865923030017849,865923030017864,865923030018029,865923030018177,865923030018219,865923030028440,865923030028499,865923030028994,865923030029000,865923030034802,865923030033481,865923030034299,865923030034703,865923030034885,865923030035015,865923030035031,865923030035114,865923030035205,865923030035270,865923030035288,865923030035395,865923030035494,865923030035650,865923030038498,865923030038662,865923030038837,865923030038845,865923030039058,865923030039413,865923030067588,865923030067596,865923030068024,865923030068057,865923030068198";
	//六点整20台测试设备。
	private String ldzZdbhs = "869081030001044,358511021123215,869081030004204,869081030002141,865923030038761,865923030011313,865923030032376,358511021145648,865923030039611,865923030039587,358511021146968,869081030000517,865923030039108,865923030006388,869081030000269,869081030001226,865923030039173,865923030011248,865923030006701";

	ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        Message message = (Message) msg;
        System.out.println(">>>>>[终端心跳],phone={},flowid={}"+message.getDeviceId()+"--"+message.getFlowId());
        accessLog.info(">>>>>[终端心跳],phone={},flowid={}", message.getDeviceId(), message.getFlowId());
        try {
            iotServer.online(ctx.channel(),message.getDeviceId());
            //当前获取id
            String deviceId = message.getDeviceId();
            String cmd = message.getCommand();
            try{
            	Map versionMap = mapper.readValue(cmd, Map.class);
                Integer versionCode = Integer.parseInt(versionMap.get("versionCode").toString());
                //自动更新武大终端设备
                if (wdZdbhs.contains(deviceId) && versionCode < 2003){
                	String json = "{\"deviceId\":\""+message.getDeviceId()+"\",\"taskId\":\"\",\"cmdType\":\"90\",\"cmd\":\"http://119.23.242.234:9092/apk/ticserver-wdvideo-V2.0.2.apk\"}";
            		Map<String,String> header = new HashMap<String, String>();
            		header.put("Content-Type","application/json");
            		String res = null;
            		try {  			
            			res = HttpUtil.postJson("http://119.23.242.234:10088/api/set/",header, json);
            			accessLog.info(">>>>>[自动升级结果],phone={},结果={}", message.getDeviceId(), res);
            		} catch (Exception e) {
            			accessLog.info("自动升级失败["+message.getDeviceId()+"]");
            		}
                }else if (ldzZdbhs.contains(deviceId) && versionCode < 2003){
                	String json = "{\"deviceId\":\""+message.getDeviceId()+"\",\"taskId\":\"\",\"cmdType\":\"90\",\"cmd\":\"http://119.23.242.234:9092/apk/ticserver-gps-V2.0-release.apk\"}";
            		Map<String,String> header = new HashMap<String, String>();
            		header.put("Content-Type","application/json");
            		String res = null;
            		try {  			
            			res = HttpUtil.postJson("http://119.23.242.234:10088/api/set/",header, json);
            			accessLog.info(">>>>>[自动升级结果],phone={},结果={}", message.getDeviceId(), res);
            		} catch (Exception e) {
            			accessLog.info("自动升级失败["+message.getDeviceId()+"]");
            		}
                }	
            }catch(Exception e){
            	errorLog.error("武大自动升级程序异常", e);
            }
            
            /*if (message.getDeviceId().equals("358511021146315") || 
            	message.getDeviceId().equals("865923030039157")	||
            	message.getDeviceId().equals("869081030002786")	||
            	message.getDeviceId().equals("869081030003230")){
            	
            }*/
            /*if (message.getCommand().indexOf("2002") == -1){
        		accessLog.info(">>>>>[自动升级设备],phone={},flowid={}", message.getDeviceId(), message.getFlowId());
        		
        		String json = "{\"deviceId\":\""+message.getDeviceId()+"\",\"taskId\":\"865923030036328901552052614304\",\"cmdType\":\"90\",\"cmd\":\"http://119.23.242.234:9092/apk/ticserver-gps.apk\"}";
        		Map<String,String> header = new HashMap<String, String>();
        		header.put("Content-Type","application/json");
        		String res = null;
        		try {  			
        			res = HttpUtil.postJson("http://119.23.242.234:10088/api/set/",header, json);
        			accessLog.info(">>>>>[自动升级结果],phone={},结果={}", message.getDeviceId(), res);
        		} catch (Exception e) {
        			accessLog.info("自动升级失败["+message.getDeviceId()+"]");
        		}
        	}*/
            super.send2Client(ctx.channel(), message);
            accessLog.info("<<<<<[终端心跳],phone={},flowid={}", message.getDeviceId(), message.getFlowId());
        } catch (Exception e) {
            errorLog.error("<<<<<[终端心跳]处理错误,phone={},flowid={},err={}", message.getDeviceId(), message.getFlowId(), e.getMessage());
            e.printStackTrace();
        }
    }
}
