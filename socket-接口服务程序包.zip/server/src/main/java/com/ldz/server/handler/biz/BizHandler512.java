package com.ldz.server.handler.biz;

import com.ldz.server.bean.RequestCommonParamsDto;
import com.ldz.server.handler.ServerChannelHandler;
import com.ldz.server.jt808.vo.PackageData;
import com.ldz.server.jt808.vo.req.LocationInfoUploadMsg;
import com.ldz.server.jt808.vo.resp.ServerCommonRespMsgBody;
import com.ldz.server.util.DateUtils;
import com.ldz.socket.common.bean.JsonUtil;
import com.ldz.socket.common.bean.LocationInfo;
import com.ldz.socket.common.bean.Message;
import io.netty.channel.ChannelHandlerContext;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * 位置数据包：
 * // 7E 02 00 00 26 12 34 56 78 90 12 00 7D 02 00 00 00 01 00 00 00 02 00 BA 7F 0E 07 E4 F1 1C 00 28 00 3C 00 00 18 10 15 10 10 10 01 04 00 00 00 64 02 02 00 7D 01 13 7E
 *
 // 3. 位置信息汇报 ==> 平台通用应答
 */
@Component
public class BizHandler512 extends BizBaseHandler {
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        Message message = (Message) msg;
       //  final PackageData.MsgHeader header = packageData.getMsgHeader();
        accessLog.info(">>>>>[位置信息],phone={},flowid={}", message.getDeviceId(), message.getFlowId());
        try {
            LocationInfo locationInfo = JsonUtil.toBean(message.getCommand(), LocationInfo.class);
//            LocationInfoUploadMsg locationInfoUploadMsg = msgDecoder.toLocationInfoUploadMsg(packageData);

//            accessLog.debug("位置 信息:{}", JSON.toJSONString(locationInfo, true));
            // final PackageData.MsgHeader reqHeader = locationInfoUploadMsg.getMsgHeader();
            ServerCommonRespMsgBody respMsgBody = new ServerCommonRespMsgBody(message.getFlowId(), message.getCode(), ServerCommonRespMsgBody.success);
            int flowId = super.getFlowId(message.getChannel());
//            String bs = messageEncoder.encode4ServerCommonRespMsg(message, respMsgBody, flowId);

            //推送GPS数据到biz中处理
            RequestCommonParamsDto dto = new RequestCommonParamsDto();
            dto.setDeviceId(message.getDeviceId());
            dto.setLatitude(""+locationInfo.getLatitude());
            dto.setLongitude(""+locationInfo.getLongitude());
            dto.setStartTime(locationInfo.getTime());
            dto.setEndTime(locationInfo.getTime());
            dto.setFxj(""+locationInfo.getDirection());
            dto.setSpeed(StringUtils.isBlank(locationInfo.getSpeed())  ? "0" : ""+locationInfo.getSpeed());
            if (dto.getSpeed().contains(".")){
                dto.setSpeed(""+Math.round(new Float(dto.getSpeed())));
            }
            dto.setStarNum(""+locationInfo.getStarNum());
            //2019年1月25日。转换后的结果，高位在前，低位在后，需要做一个反转
            // String alarmCode = StringUtils.rightPad(StringUtils.reverse(Integer.toBinaryString(locationInfoUploadMsg.getWarningFlagField())),32,'0');

            int statusField = locationInfo.getStatusField();
            //statusField:1,statusField:0
            String eventType = null;
            //通道当前状态。
            Integer s = ctx.channel().attr(ServerChannelHandler.STATUS).get();
            if (statusField != s){
                //处理点火熄火事件上报
                if (statusField == 1){
                    eventType = "50";
                }else{
                    eventType = "60";
                }
                ctx.channel().attr(ServerChannelHandler.STATUS).set(statusField);
            }
            /*String statucFieldStr = Integer.toBinaryString(statusField);
            if (statucFieldStr.charAt(0) == '0'){
                eventType = "60";
            }else{
                eventType = parseEventType(alarmCode);
            }*/

            dto.setEventType(eventType);
            dto.setSczt("10");
            handleEvent(locationInfo.getEventType(),dto);

//            super.send2Client(message.getChannel(), bs);
            accessLog.info("<<<<<[位置信息],phone={},flowid={}",message.getDeviceId(), message.getFlowId());
        } catch (Exception e) {
            errorLog.error("<<<<<[位置信息]处理错误,phone={},flowid={},err={}", message.getDeviceId(), message.getFlowId(), e.getMessage());
            e.printStackTrace();
        }
    }

    private void handleEvent(String s,RequestCommonParamsDto dto){
        Map<Integer,String> codeMap = new HashMap<>();
        codeMap.put(9,"10"); // 急加速
        codeMap.put(10,"20"); // 急减速
        codeMap.put(11,"31"); // 急左转弯
        codeMap.put(14,"32"); // 急右转弯
        codeMap.put(12,"33"); // 急左变道
        codeMap.put(15,"34"); // 急右变道

//        boolean hasEvent = false;

        if(!codeMap.containsValue(s)) {
            redisDao.convertAndSend("gps", dto);
        }else {
            dto.setEventType(s);
            redisDao.convertAndSend("gps", dto);
        }


       /* for (int i = 0;i<s.length();i++){
            if (!codeMap.containsValue(i))continue;
            char c = s.charAt(i);
            if (c != '1')continue;
            hasEvent = true;
            dto.setEventType(codeMap.get(i));
            redisDao.convertAndSend("gps", dto);
        }
        if (!hasEvent){
            redisDao.convertAndSend("gps", dto);
        }*/
    }
}
