package com.ldz.server.handler.biz;

import com.ldz.server.jt808.vo.Session;
import com.ldz.server.jt808.vo.resp.ServerCommonRespMsgBody;
import com.ldz.socket.common.bean.Message;
import io.netty.channel.ChannelHandlerContext;
import org.springframework.stereotype.Component;

/**
 *
 // 5. 终端鉴权 ==> 平台通用应答
 */
@Component
public class BizHandler258 extends BizBaseHandler{
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        Message message = (Message) msg;
       //  final PackageData.MsgHeader header = message.getMsgHeader();
        accessLog.info(">>>>>[终端鉴权],phone={},flowid={}", message.getDeviceId(), message.getFlowId());
        try {
//            TerminalAuthenticationMsg authenticationMsg = new TerminalAuthenticationMsg(packageData);

//            accessLog.debug("终端鉴权:{}", JSON.toJSONString(msg, true));
            final String sessionId = Session.buildId(message.getChannel());
            Session session = sessionManager.findBySessionId(sessionId);
            if (session == null) {
                session = Session.buildSession(message.getChannel(), message.getDeviceId());
            }
            session.setAuthenticated(true);
            session.setTerminalPhone(message.getDeviceId());
            sessionManager.put(session.getId(), session);

            ServerCommonRespMsgBody respMsgBody = new ServerCommonRespMsgBody();
            String authCode = iotServer.getAuthCodeByPhone(message.getDeviceId());
            if (authCode == null || !authCode.equals(message.getAuthCode())){
                respMsgBody.setReplyCode(ServerCommonRespMsgBody.failure);
            }else{
                respMsgBody.setReplyCode(ServerCommonRespMsgBody.success);
            }
            iotServer.online(message.getChannel(),message.getDeviceId());
            respMsgBody.setReplyFlowId(message.getFlowId());
            respMsgBody.setReplyId(message.getCode());
            int flowId = super.getFlowId(message.getChannel());
//            String bs = messageEncoder.encode4ServerCommonRespMsg(message, respMsgBody, flowId);
//            super.send2Client(message.getChannel(), bs);

            accessLog.info("<<<<<[终端鉴权],phone={},flowid={}", message.getDeviceId(), message.getFlowId());
        } catch (Exception e) {
            errorLog.error("<<<<<[终端鉴权]处理错误,phone={},flowid={},err={}", message.getDeviceId(), message.getFlowId(), e.getMessage());
            e.printStackTrace();
        }
    }
}
