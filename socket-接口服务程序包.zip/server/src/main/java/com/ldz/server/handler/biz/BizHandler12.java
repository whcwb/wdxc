package com.ldz.server.handler.biz;

import com.ldz.server.jt808.vo.resp.ServerCommonRespMsgBody;
import com.ldz.socket.common.bean.JsonUtil;
import com.ldz.socket.common.bean.Message;
import com.ldz.socket.common.command.CommandGps;
import io.netty.channel.ChannelHandlerContext;
import org.springframework.stereotype.Component;

/**
 *  位置上报
 */
@Component
public class BizHandler12 extends BizBaseHandler {

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) {
        Message message = (Message) msg;
        accessLog.info(">>>>>[GPS点位],phone={},flowid={}", message.getDeviceId(), message.getFlowId());
        try {
            CommandGps commandGps = JsonUtil.toBean(message.getCommand(), CommandGps.class);

            accessLog.info("<<<<<[GPS点位],phone={},flowid={}", message.getDeviceId(), message.getFlowId());
            Message resultMsg = new Message();
            resultMsg.setCode(12);
            resultMsg.setDeviceId(message.getDeviceId());
            resultMsg.setCommand("GPS上报成功");
            super.send2Client(message.getChannel(), resultMsg);
        } catch (Exception e) {
            errorLog.error("<<<<<[GPS点位]处理错误,phone={},flowid={},err={}", message.getDeviceId(), message.getFlowId(), e.getMessage());
            e.printStackTrace();
        }
    }
}
