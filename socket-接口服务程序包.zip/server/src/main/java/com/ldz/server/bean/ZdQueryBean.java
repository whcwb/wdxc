package com.ldz.server.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ZdQueryBean {

    private String deviceId;

    private String query;

}
