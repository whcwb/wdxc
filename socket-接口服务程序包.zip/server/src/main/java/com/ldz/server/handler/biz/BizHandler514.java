package com.ldz.server.handler.biz;

import com.ldz.server.bean.RequestCommonParamsDto;
import com.ldz.server.jt808.vo.PackageData;
import com.ldz.server.jt808.vo.req.BatchLocationInfoUploadMsg;
import com.ldz.server.jt808.vo.req.LocationInfoUploadMsg;
import com.ldz.server.jt808.vo.resp.ServerCommonRespMsgBody;
import com.ldz.socket.common.bean.JsonUtil;
import com.ldz.socket.common.bean.LocationInfo;
import com.ldz.socket.common.bean.Message;
import io.netty.channel.ChannelHandlerContext;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 位置数据包：
 * // 7E 02 00 00 26 12 34 56 78 90 12 00 7D 02 00 00 00 01 00 00 00 02 00 BA 7F 0E 07 E4 F1 1C 00 28 00 3C 00 00 18 10 15 10 10 10 01 04 00 00 00 64 02 02 00 7D 01 13 7E
 *
 // 3. 位置信息汇报 ==> 平台通用应答
 */
@Component
public class BizHandler514 extends BizBaseHandler {
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        Message message = (Message) msg;
        // final PackageData.MsgHeader header = packageData.getMsgHeader();
        accessLog.info(">>>>>[位置信息],phone={},flowid={}", message.getDeviceId(), message.getFlowId());
        try {
            List<LocationInfo> list = JsonUtil.toList(message.getCommand(), LocationInfo.class);

            // BatchLocationInfoUploadMsg batchLocationInfoUploadMsg = msgDecoder.toBatchLocationInfoUploadMsg(packageData);
//            accessLog.debug("位置 信息:{}", JSON.toJSONString(list, true));
            for (LocationInfo gps : list) {
                handleGps(gps,message);
            }
            accessLog.info("<<<<<[位置信息],phone={},flowid={}", message.getDeviceId(), message.getFlowId());
        } catch (Exception e) {
            errorLog.error("<<<<<[位置信息]处理错误,phone={},flowid={},err={}", message.getDeviceId(), message.getFlowId(), e.getMessage());
            e.printStackTrace();
        }
    }

    private void handleGps(LocationInfo info,Message message){
       //  final PackageData.MsgHeader header = locationInfoUploadMsg.getMsgHeader();
        try {
//            accessLog.debug("位置 信息:{}", JSON.toJSONString(info, true));
            // final PackageData.MsgHeader reqHeader = locationInfoUploadMsg.getMsgHeader();
            ServerCommonRespMsgBody respMsgBody = new ServerCommonRespMsgBody(message.getFlowId(), message.getCode(), ServerCommonRespMsgBody.success);
            int flowId = super.getFlowId(message.getChannel());
//            String bs = messageEncoder.encode4ServerCommonRespMsg(message, respMsgBody, flowId);

            //推送GPS数据到biz中处理
            RequestCommonParamsDto dto = new RequestCommonParamsDto();

            dto.setDeviceId(message.getDeviceId());
            dto.setLatitude(""+info.getLatitude());
            dto.setLongitude(""+info.getLongitude());
            dto.setStartTime(info.getTime());
            dto.setEndTime(info.getTime());
            dto.setFxj(""+info.getDirection());
            dto.setSpeed(StringUtils.isBlank(info.getSpeed()) ? "0" : ""+info.getSpeed());
            if (dto.getSpeed().contains(".")){
                dto.setSpeed(""+Math.round(new Float(dto.getSpeed())));
            }
//            String alarmCode = Integer.toBinaryString(locationInfoUploadMsg.getWarningFlagField());
//            String eventType = parseEventType(alarmCode);
            dto.setEventType(info.getEventType());
            dto.setSczt("10");
            redisDao.convertAndSend("gps", dto);
//            super.send2Client(message.getChannel(), bs);
            accessLog.info("<<<<<[位置信息],phone={},flowid={}", message.getDeviceId(), message.getFlowId());
        } catch (Exception e) {
            errorLog.error("<<<<<[位置信息]处理错误,phone={},flowid={},err={}", message.getDeviceId(), message.getFlowId(), e.getMessage());
            e.printStackTrace();
        }
    }


    /*private String parseEventType(String s){
        Map<Integer,String> codeMap = new HashMap<>();
        codeMap.put(9,"10"); // 急加速
        codeMap.put(10,"20"); // 急减速
        codeMap.put(11,"31"); // 急左转弯
        codeMap.put(14,"32"); // 急右转弯
        codeMap.put(12,"33"); // 急左变道
        codeMap.put(15,"34"); // 急右变道

        for (int i = 0;i<s.length();i++){
            if (!codeMap.containsKey(i))continue;
            char c = s.charAt(i);
            if (c != 1)continue;
            return codeMap.get(i);
        }
        return null;
    }*/
}
