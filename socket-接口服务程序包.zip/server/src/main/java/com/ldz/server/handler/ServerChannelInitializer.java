package com.ldz.server.handler;

import com.ldz.socket.common.adapter.MessageDecoder;
import com.ldz.socket.common.constant.MessageConfig;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.DelimiterBasedFrameDecoder;
import io.netty.handler.timeout.ReadTimeoutHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
public class ServerChannelInitializer extends ChannelInitializer<SocketChannel> {

	//读操作空闲35分钟
	public final static int READER_IDLE_TIME_SECONDS = 30;

	@Autowired
	private ServerChannelHandler serverHandler;

	@Override
	protected void initChannel(SocketChannel socketChannel) throws Exception {
		ChannelPipeline pipeline = socketChannel.pipeline();
		pipeline.addLast(new DelimiterBasedFrameDecoder(1024, Unpooled.copiedBuffer(MessageConfig.INSTANCE.getHead().getBytes()), Unpooled.copiedBuffer(MessageConfig.INSTANCE.getTail().getBytes())));
		//解包转换类
		pipeline.addLast(new MessageDecoder(1024, Unpooled.copiedBuffer(MessageConfig.INSTANCE.getHead().getBytes()), Unpooled.copiedBuffer(MessageConfig.INSTANCE.getTail().getBytes())));
        //设置心跳检测。单位为分钟
		pipeline.addLast(new ReadTimeoutHandler(READER_IDLE_TIME_SECONDS, TimeUnit.MINUTES));

        pipeline.addLast(serverHandler);
	}
}
