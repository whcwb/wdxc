package com.ldz.server.handler.biz;

import com.ldz.socket.common.bean.JsonUtil;
import com.ldz.socket.common.bean.Message;
import com.ldz.socket.common.command.CommandBatchGps;
import com.ldz.socket.common.command.CommandGps;
import io.netty.channel.ChannelHandlerContext;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 批量GPS点位上报
 */
@Component
public class BizHandler13 extends BizBaseHandler {

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) {
        Message message = (Message) msg;
        accessLog.info(">>>>>[批量GPS点位],phone={},flowid={}", message.getDeviceId(), message.getFlowId());
        try {
            CommandBatchGps batchGps = JsonUtil.toBean(message.getCommand(), CommandBatchGps.class);
            List<CommandGps> gpsList = batchGps.getGpsList();
            accessLog.info(">>>>>[批量GPS点位]:", JsonUtil.toJson(gpsList));
            System.out.println(">>>>>[批量GPS点位]:"+ JsonUtil.toJson(gpsList));
            super.send2Client(message.getChannel(),message);
        }catch (Exception e){

        }
    }

}
