package com.ldz.server.jt808.vo.req;

import com.ldz.server.jt808.vo.PackageData;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TravelData extends PackageData {
    private String startTime;
    private String endTime;
    private int milage;
    private String startLng;
    private String startLat;
    private String endLat;
    private String endLng;

    public TravelData() {
    }

    public TravelData(PackageData packageData) {
        this();
        this.channel = packageData.getChannel();
        this.checkSum = packageData.getCheckSum();
        this.msgBodyBytes = packageData.getMsgBodyBytes();
        this.msgHeader = packageData.getMsgHeader();


    }

}
