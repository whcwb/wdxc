package com.ldz.server.server;

import com.ldz.server.bean.ApiResponse;
import com.ldz.server.bean.DeviceBean;
import com.ldz.server.bean.RequestCommonParamsDto;
import com.ldz.server.exception.RuntimeCheck;
import com.ldz.server.exception.RuntimeCheckException;
import com.ldz.server.handler.ServerChannelHandler;
import com.ldz.server.handler.ServerChannelInitializer;
import com.ldz.server.util.RedisTemplateUtil;
import com.ldz.socket.common.bean.JsonUtil;
import com.ldz.socket.common.bean.Message;
import com.ldz.socket.common.command.CommandSetting;
import com.ldz.socket.common.constant.CommandCode;
import com.ldz.socket.common.util.CommandUtil;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.util.concurrent.GlobalEventExecutor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * socket服务端
 * @author Lee
 *
 */
@Configuration
@Slf4j
public class IotServer {

	@Autowired
	private ServerBootstrap server;
	@Autowired
	private InetSocketAddress tcpSocket;
	@Autowired
	private RedisTemplateUtil redisDao;

	private Channel serverChannel;
	public final static String ONLINE_KEY = "ONLINE";
	public final static String PHONE_DEVICEID = "JT808_PHONE_DEVICEID-";
	public final static String PHONE_AUTHCODE = "JT808_PHONE_AUTHCODE-";
	//在线通道列表
	public static ChannelGroup onlineChannels = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);

	public void putPhoneDevice(String phone,String deviceId){
		String key = PHONE_DEVICEID+phone;
		redisDao.boundValueOps(key).set(deviceId);
		redisDao.boundValueOps(key).expire(ServerChannelInitializer.READER_IDLE_TIME_SECONDS, TimeUnit.MINUTES);
	}

	public String getDeviceIdByPhone(String phone){
		String key = PHONE_DEVICEID+phone;
		if (!redisDao.hasKey(key)) return null;
		String s = (String) redisDao.boundValueOps(key).get();
		return s;
	}
	public void putAuthCode(String phone,String authCode){
		String key = PHONE_AUTHCODE+phone;
		redisDao.boundValueOps(key).set(authCode);
		redisDao.boundValueOps(key).expire(ServerChannelInitializer.READER_IDLE_TIME_SECONDS, TimeUnit.MINUTES);
	}

	public String getAuthCodeByPhone(String phone){
		String key = PHONE_AUTHCODE+phone;
		if (!redisDao.hasKey(key)) return null;
		String s = (String) redisDao.boundValueOps(key).get();
		return s;
	}
	/**
	 * 通道channel ID获取在线终端ID
	 * @param cid
	 * @return
	 */
	public String getTid(String cid){
		String tid = null;
		//主动移除终端在线状态.Redis
		Iterator<Object> keys = redisDao.keys("*-"+cid+"-"+ONLINE_KEY).iterator();
		while(keys.hasNext()){
			String key = keys.next().toString();
			tid = key.split("-")[0];
			break;
		}

		return tid;
	}

	/**
	 * 查找一个终端是否在线
	 * @param tid
	 * @return
	 */
	public boolean isOnline(String tid){
		return redisDao.keys(tid+"-*-"+ONLINE_KEY).iterator().hasNext();
	}


	/**
	 * 在线列表
	 * @return
	 */
	public List<String> getOnlineList(){
		List<String> deviceIds = new ArrayList<>();
		for (Channel channel : IotServer.onlineChannels) {
			String deviceId = channel.attr(ServerChannelHandler.DEVICENO).get();
			deviceIds.add(deviceId);
		}
		return deviceIds;
	}
	public void online(Channel channel,String tid){
		if (StringUtils.isBlank(tid)){
			return;
		}
		final String tmpId = tid;

		//将通道放入group中
		if (!IotServer.onlineChannels.contains(channel)){
			//查看相同的终端号之前是否有保留的通道，如果有则自动清理掉旧通道
			IotServer.onlineChannels.removeIf(c->{
				String deviceNo = c.attr(ServerChannelHandler.DEVICENO).get();
				if (StringUtils.isNotBlank(deviceNo) && tmpId.equals(deviceNo)){
					c.close();
					return true;
				}

				return false;
			});
			//为通道设置终端no属性值
			channel.attr(ServerChannelHandler.DEVICENO).set(tid);
			IotServer.onlineChannels.add(channel);
		}

		String cid = channel.id().asShortText();
		String time = DateTime.now().toString("yyyy-MM-dd HH:mm:ss");
		String onlineKey = tid+"-"+cid+"-"+IotServer.ONLINE_KEY;
		DeviceBean device = new DeviceBean();
		device.setImei(tid);
		device.setTime(time);
		redisDao.boundValueOps(onlineKey).set(device);
		redisDao.boundValueOps(onlineKey).expire(ServerChannelInitializer.READER_IDLE_TIME_SECONDS, TimeUnit.MINUTES);
	}
	/**
	 * 刷新在线列表
	 */
	public void online(ChannelHandlerContext ctx, String tid){
		online(ctx.channel(),tid);
	}

	/**
	 * 更新终端信息，
	 * @param ctx
	 * @param tid
	 * @param sbgn
	 */
	public void updateDevice(ChannelHandlerContext ctx, String tid, String sbgn){
		if (StringUtils.isBlank(tid)){
			return;
		}

		String cid = ctx.channel().id().asShortText();
		String time = DateTime.now().toString("yyyy-MM-dd HH:mm:ss");
		String onlineKey = tid+"-"+cid+"-"+IotServer.ONLINE_KEY;
		DeviceBean device = new DeviceBean();
		device.setImei(tid);
		device.setTime(time);
		device.setSbgn(sbgn);
		redisDao.boundValueOps(onlineKey).set(device);
		redisDao.boundValueOps(onlineKey).expire(ServerChannelInitializer.READER_IDLE_TIME_SECONDS, TimeUnit.MINUTES);
	}

	/**
	 * 向终端发送数据
	 * @param
	 */
	public void sendMsg(String deviceId, Message message){
		Channel onlineChannel = IotServer.onlineChannels.parallelStream().filter(channel -> {
			String id = channel.attr(ServerChannelHandler.DEVICENO).get();
			return deviceId.equals(id);
		}).findFirst().orElseThrow(()->new RuntimeCheckException("当前终端未在线！"));

		//指令发送
		//onlineChannel.writeAndFlush(message);
		CommandUtil.INSTANCE.sendMessage(onlineChannel,message);
	}



	public String getDeviceIdByChannel(Channel channel){
		Iterator<Channel> it = IotServer.onlineChannels.iterator();
		while(it.hasNext()){
			Channel c = it.next();
			if (c.id().equals(channel.id())){
				return c.attr(ServerChannelHandler.DEVICENO).get();
			}
		}
		return null;
	}

	@PostConstruct
	public void start() throws Exception{
		log.info("启动服务器 " + tcpSocket);
		new Thread(new Runnable() {
			@Override
			public void run() {
				try{
					serverChannel = server.bind(tcpSocket).sync().channel().closeFuture().sync().channel();
				}catch(Exception e){

				}

			}
		}).start();
	}

	@PreDestroy
	public void stop() throws Exception{
		log.info("停止服务器 " + tcpSocket);
		serverChannel.close();
		serverChannel.parent().close();
	}

	public ApiResponse<String> checkOnline(String zdbh) {
		boolean online = isOnline(zdbh);
		if(online){
			return ApiResponse.success("online");
		}else {
			return ApiResponse.fail("not online");
		}

	}


	public ApiResponse<String> set(RequestCommonParamsDto dto) {
		System.out.println(JsonUtil.toJson(dto));
		Message message = new Message();
		message.setCode(CommandCode.SETTING.getCode());
		message.setDeviceId(dto.getDeviceId());
		message.setCommand(JsonUtil.toJson(dto));
		sendMsg(dto.getDeviceId(),message);
		return ApiResponse.success();
	}
//	public ApiResponse<String> set(String code, String param, String zdbh) {
//		CommandSetting setting = new CommandSetting(zdbh);
//		RuntimeCheck.ifBlank(code, "请设置参数类型");
//		setting.setType(code);
//		if(StringUtils.equals(code,"3") || StringUtils.equals(code, "5") || StringUtils.equals(code, "6")){
//			RuntimeCheck.ifBlank(param, "请上传设置参数");
//			setting.setParam(param);
//		}
//		Message message = new Message();
//		message.setCode(CommandCode.SETTING.getCode());
//		message.setDeviceId(zdbh);
//		message.setCommand(JsonUtil.toJson(setting));
//		sendMsg(zdbh,message);
//		return ApiResponse.success();
//	}
}
