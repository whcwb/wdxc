package com.ldz.server.handler.biz;

import com.ldz.server.jt808.vo.Session;
import com.ldz.server.jt808.vo.resp.TerminalRegisterMsgRespBody;
import com.ldz.socket.common.bean.JsonUtil;
import com.ldz.socket.common.bean.Message;
import com.ldz.socket.common.bean.TerminalRegMsg;
import io.netty.channel.ChannelHandlerContext;
import org.apache.commons.lang.RandomStringUtils;
import org.springframework.stereotype.Component;

/**
 *
 // 6. 终端注册 ==> 终端注册应答
 */
@Component
public class BizHandler256 extends BizBaseHandler {

    private static final String DEVICEID = "DEVICEID-";
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        Message message = (Message) msg;
       //  final PackageData.MsgHeader header = packageData.getMsgHeader();
        accessLog.info(">>>>>[终端注册],phone={},flowid={}", message.getDeviceId(), message.getFlowId());
        try {

            TerminalRegMsg terminalRegMsg = JsonUtil.toBean(message.getCommand(), TerminalRegMsg.class);

           // TerminalRegisterMsg terminalRegisterMsg = msgDecoder.toTerminalRegisterMsg(packageData);

//            accessLog.debug("终端注册:{}", JSON.toJSONString(msg, true));

            final String sessionId = Session.buildId(message.getChannel());
            Session session = sessionManager.findBySessionId(sessionId);
            if (session == null) {
                session = Session.buildSession(message.getChannel(), message.getDeviceId());
            }
            session.setAuthenticated(true);
            session.setTerminalPhone( message.getDeviceId());
            sessionManager.put(session.getId(), session);

            iotServer.putPhoneDevice( message.getDeviceId(), terminalRegMsg.getTerminalId());
            // 检查终端编号是否存在
            TerminalRegisterMsgRespBody respMsgBody = new TerminalRegisterMsgRespBody();
            if (!redisDao.hasKey(DEVICEID+message.getDeviceId())){
                errorLog.error("终端不存在："+message.getDeviceId());
                respMsgBody.setReplyCode(TerminalRegisterMsgRespBody.success);
//                respMsgBody.setReplyCode(TerminalRegisterMsgRespBody.terminal_not_found);
            }else{
                respMsgBody.setReplyCode(TerminalRegisterMsgRespBody.success);
            }
            respMsgBody.setReplyFlowId(message.getFlowId());
            String chars = "qwertyuiopasdfghjklzxcvbnmZXCVBNMASDFGHJKLQEWRTYUIOP";
            String replyToken = RandomStringUtils.random(16,chars);
            respMsgBody.setReplyToken(replyToken);
            iotServer.putAuthCode(message.getDeviceId(),replyToken);
            int flowId = super.getFlowId(message.getChannel());
//            String bs = messageEncoder.encode4TerminalRegisterResp(message, respMsgBody, flowId);
//            super.send2Client(message.getChannel(), bs);
            accessLog.info("<<<<<[终端注册],phone={},flowid={}", message.getDeviceId(), message.getFlowId());
        } catch (Exception e) {
            errorLog.error("<<<<<[终端注册]处理错误,phone={},flowid={},err={}", message.getDeviceId(), message.getFlowId(), e.getMessage());
            e.printStackTrace();
        }
    }
}
