package com.ldz.server.api;

import com.ldz.server.bean.ApiResponse;
import com.ldz.server.bean.RequestCommonParamsDto;
import com.ldz.server.bean.ZdQueryBean;
import com.ldz.server.server.IotServer;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * 协议对外接口提供
 * 用于其他平台进行设备的指令操作
 * @author Lee
 *
 */
@RestController
@RequestMapping("/api")
public class Api {

	@Autowired
	private IotServer iotServer;
	Logger errorLog = LoggerFactory.getLogger("error_info");

	/**
	 * 终端设置参数
	 * @return
	 */
	@PostMapping("/set")
	public ApiResponse<String> set(@RequestBody RequestCommonParamsDto dto) throws Exception {
		iotServer.set(dto);
		return ApiResponse.success();
	}
//	@PostMapping("/set")
//	public ApiResponse<String> set(String code, String param, String zdbh) throws Exception {
//		RuntimeCheck.ifBlank(zdbh, "终端编号不能为空");
//		iotServer.set(code, param, zdbh);
//		return ApiResponse.success();
//	}

	/**
	 * 查询终端参数
	 */
	@PostMapping("/query")
	public ApiResponse<String> query(ZdQueryBean entity){
		return ApiResponse.success();
	}

	/**
	 * 查询终端是否在线
	 */
	@GetMapping("/checkOnline")
	public ApiResponse<String> checkOnline(String zdbh){
		if(StringUtils.isBlank(zdbh)){
			return ApiResponse.fail("请输入终端编号");
		}
		return iotServer.checkOnline(zdbh);
	}
	/**
	 * 获取所有在线终端
	 */
	@GetMapping("/getAllOnline")
	public ApiResponse<List<String>> getAllOnLine(){
		ApiResponse<List<String>> response = new ApiResponse<>();
		List<String> onlineList = iotServer.getOnlineList();
		if(CollectionUtils.isEmpty(onlineList)){
			response.setCode(500);
			response.setMessage("当前没有设备在线");
		}
		response.setResult(onlineList);
		return response;
	}

}
