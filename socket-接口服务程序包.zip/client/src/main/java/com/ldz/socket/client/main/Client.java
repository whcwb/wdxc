package com.ldz.socket.client.main;

import com.ldz.socket.client.handler.ClientChannelInitializer;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelOption;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;

public enum Client {
    INSTANCE;
//    private String host = "192.168.123.6";
//    private String host = "119.23.242.234";
    private String host = "127.0.0.1";
    private int port = 9900;
    private String deviceId = "111111111111";
    private Channel channel;
    private Bootstrap bootstrap;
    private int reconnectCount = 0;
    private int maxReconnectCount = 13;
    //接收数据最大缓存数据长度
    private final static Integer RECEIVE_BUFFER_LENGTH = 1024 * 1024;
    //发送数据缓存长度
    private final static int SEND_BUFFER_LENGTH = 1024;


    public boolean isReconnection(){
        return reconnectCount != 0;
    }
    public boolean reconnectTimeout(){
        return reconnectCount > maxReconnectCount;
    }
    public void reconnect(){
        System.out.println("reconnect");
        if (reconnectTimeout()){
            System.out.println("重连次数过多");
            return;
        }
        System.out.println("第"+(reconnectCount + 1)+"次重连。。。");
        channel = bootstrap.connect(host, port).channel();
        if (channel.isActive()){
            System.out.println("重连成功！");
            reconnectCount = 0;
            channel.eventLoop().shutdownGracefully();
            return;
        }else{
            reconnectCount ++;
            System.out.println("重连失败");
        }
    }

    public void start() throws InterruptedException {
        ClientChannelInitializer initializer = new ClientChannelInitializer();
        try{
            bootstrap = new Bootstrap();
            bootstrap.group(new NioEventLoopGroup())
                    .channel(NioSocketChannel.class)
                    .option(ChannelOption.TCP_NODELAY, true)
                    .option(ChannelOption.SO_RCVBUF, RECEIVE_BUFFER_LENGTH)
                    .option(ChannelOption.SO_SNDBUF, SEND_BUFFER_LENGTH)
                    .option(ChannelOption.SO_BACKLOG, 50)
                    .option(ChannelOption.SO_KEEPALIVE, true)
                    .handler(initializer);

            channel = bootstrap.connect(host, port).channel();
        }catch (Exception e){
            e.printStackTrace();
//        }finally {
//            if (reconnectTimeout()){
//                System.out.println("重连次数过多");
//                return;
//            }
//            System.out.println("start");
//            Thread.sleep(5000);
//            reconnectCount ++;
//            start();
        }
    }

    public String getDeviceId() {
        return deviceId;
    }

    public Channel getChannel() {
        return channel;
    }
}
