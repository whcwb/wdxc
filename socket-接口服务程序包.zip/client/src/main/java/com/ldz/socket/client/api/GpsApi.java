package com.ldz.socket.client.api;

import com.ldz.socket.client.main.Client;
import com.ldz.socket.common.bean.Message;
import com.ldz.socket.common.command.CommandBatchGps;
import com.ldz.socket.common.command.CommandGps;
import com.ldz.socket.common.util.CommandUtil;

public class GpsApi {

    /**
     * 发送gps
     * @param commandGps
     */
    public void sendGps(CommandGps commandGps){
        Message message = new Message(commandGps);
        CommandUtil.INSTANCE.sendMessage(Client.INSTANCE.getChannel(),message);
    }

    /**
     * 批量发送gps
     * @param command
     */
    public void sendBatchGps(CommandBatchGps command){
        Message message = new Message(command);
        CommandUtil.INSTANCE.sendMessage(Client.INSTANCE.getChannel(),message);
    }
}
