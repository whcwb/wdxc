package com.ldz.socket.client.handler;

import com.google.common.util.concurrent.RateLimiter;
import com.ldz.socket.client.handler.biz.ClientBaseHandler;
import com.ldz.socket.client.main.Client;
import com.ldz.socket.common.command.BaseCommand;
import com.ldz.socket.common.command.CommandBatchGps;
import com.ldz.socket.common.command.CommandGps;
import com.ldz.socket.common.constant.CommandCode;
import com.ldz.socket.common.bean.Message;
import com.ldz.socket.common.command.CommandHeartbeat;
import com.ldz.socket.common.util.CommandUtil;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.EventLoop;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;
import io.netty.util.AttributeKey;
import io.netty.util.ReferenceCountUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

public class ClientEventHandler extends ChannelInboundHandlerAdapter {

    //业务处理handler在通道中的名称
    final static String PIPELINE_BIZ_HANDLER_NAME = "serviceHandler";
    //通道终端no属性字段
    public final static AttributeKey<String> DEVICENO = AttributeKey.newInstance("deviceno");
    //同步执行属性
    public final static AttributeKey<CountDownLatch> SYNC = AttributeKey.newInstance("sync");
    //命令队列属性字段。因为同一个通道同一时间只能有一个命令执行，命令不能同时执行，所以需要队列方式来保存需要执行的命令
    public final static AttributeKey<LinkedBlockingQueue<Message>> CMDQUEUE = AttributeKey.newInstance("queue");
    //限速器
    private RateLimiter QPSLimiter;
    public ClientEventHandler() {
        super();
    }

    // 连接成功后，向server发送消息
    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        System.out.println("连接成功");
        Message message = new Message(new CommandHeartbeat(Client.INSTANCE.getDeviceId()));
        CommandUtil.INSTANCE.sendMessage(ctx.channel(),message);
    }


    /**
     * 接收发送的消息，最后需要手工release接收数据的ByteBuf
     */
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) {
        try{
            Message message = (Message)msg;
            System.out.println("receive :"+message.toString());
            message.setChannel(ctx.channel());
            CountDownLatch cd = ctx.channel().attr(ClientEventHandler.SYNC).get();
            if (cd != null){
                //执行获取数据成功，解除发送命令锁定状态
                cd.countDown();
                //重置同步标记为null，表示命令接收成功
                ctx.channel().attr(ClientEventHandler.SYNC).set(null);
            }
            if (!QPSLimiter.tryAcquire()){
                //超过每秒限流值，将不处理该消息内容
                return;
            }

            //先移除通道内的业务handler，根据实际命令码，加载新的handler进行业务处理
            if (ctx.pipeline().get(PIPELINE_BIZ_HANDLER_NAME) != null){
                ctx.pipeline().remove(PIPELINE_BIZ_HANDLER_NAME);
            }
            // 根据命令类型判断是否有相应的处理器
            int code = message.getCode();
            CommandCode commandCode = CommandCode.toEnum(code);
            if (commandCode == null){
                System.out.println("未知命令类型");
                return;
            }
            try {
                ClientBaseHandler handler = (ClientBaseHandler) Class.forName("Handler"+commandCode.getName()).newInstance();
                ctx.pipeline().addLast(PIPELINE_BIZ_HANDLER_NAME, handler);
            } catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
                e.printStackTrace();
            }
            //将消息向下传递
            ctx.fireChannelRead(msg);
        }finally{
            //手工release接收数据的ByteBuf，防止内存溢出
            ReferenceCountUtil.release(msg);
        }
    }
    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt)
            throws Exception {
        if (evt instanceof IdleStateEvent) {  // 2
            IdleStateEvent event = (IdleStateEvent) evt;
            String type = "";
            if (event.state() == IdleState.READER_IDLE) {
                type = "read idle";
            } else if (event.state() == IdleState.WRITER_IDLE) {
                type = "write idle";
            } else if (event.state() == IdleState.ALL_IDLE) {
                type = "all idle";
            }
            Message message = null;
            try{
                message = new Message(new CommandHeartbeat(Client.INSTANCE.getDeviceId()));
            }catch (Exception e){
                e.printStackTrace();
            }
            CommandUtil.INSTANCE.sendMessage(ctx.channel(),message);

            // todo test
            CommandGps commandGps = new CommandGps(Client.INSTANCE.getDeviceId());
            commandGps.setSpeed("120");
            commandGps.setLatitude("110");
            commandGps.setLongitude("30");
            commandGps.setEventType("50");

            List<CommandGps> gpsList = new ArrayList<>();
            gpsList.add(commandGps);
            gpsList.add(commandGps);

            CommandBatchGps commandBatchGps = new CommandBatchGps(Client.INSTANCE.getDeviceId());
            commandBatchGps.setGpsList(gpsList);
            Message messageGps = new Message(commandBatchGps);
            CommandUtil.INSTANCE.sendMessage(ctx.channel(),messageGps);



            System.out.println( ctx.channel().remoteAddress()+"超时类型：" + type);
        } else {
            super.userEventTriggered(ctx, evt);
        }
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        if (Client.INSTANCE.isReconnection()){
            System.out.println("重连中。。。");
        }else{
            System.err.println("掉线了,正在重连...");
        }
        //使用过程中断线重连
        Client.INSTANCE.reconnect();
        if (Client.INSTANCE.reconnectTimeout()){
            System.out.println("重连次数过多");
            super.channelInactive(ctx);
            return;
        }
        final EventLoop eventLoop = ctx.channel().eventLoop();
        eventLoop.schedule(Client.INSTANCE::reconnect, 15L, TimeUnit.SECONDS);
        System.out.println("schedule");
//        super.channelInactive(ctx);
    }
}
