package com.ldz.socket.client.handler.biz;

import com.ldz.socket.common.bean.JsonUtil;
import com.ldz.socket.common.bean.Message;
import com.ldz.socket.common.command.CommandSetting;
import com.ldz.socket.common.constant.SettingType;
import com.ldz.socket.common.exception.RuntimeCheck;
import io.netty.channel.ChannelHandlerContext;

public class HandlerSetting extends ClientBaseHandler {

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        Message message = (Message)msg;
        CommandSetting command;
        try{
            command = JsonUtil.toBean(message.getCommand(),CommandSetting.class);
        }catch (Exception e){
            e.printStackTrace();
            return;
        }
        System.out.println("command:"+command.toString());
        SettingType settingType = SettingType.toEnum(command.getType());
        RuntimeCheck.ifNull(settingType,"未知参数类型");
        System.out.println(settingType.getName());
        switch (settingType){
            case TAKE_PHOTO:
                break;
            case TAKE_VIDEO:
                break;
            case UPDATE:
                break;
            case SET_UPLOAD_DMODE:
                break;
        }
    }
}
