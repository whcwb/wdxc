package com.ldz.socket.client.main;


public class Main {

    public static void main(String[] args) throws InterruptedException {
        Client.INSTANCE.start();
    }
}
