package com.ldz.socket.client.handler;

import com.ldz.socket.common.adapter.MessageDecoder;
import com.ldz.socket.common.constant.MessageConfig;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.timeout.IdleStateHandler;



public class ClientChannelInitializer extends ChannelInitializer<SocketChannel> {
	//读操作空闲8分钟
	private static final int TIME_OUT_SECONDS = 7; // 所有超时

	@Override
	protected void initChannel(SocketChannel socketChannel) {
		ChannelPipeline pipeline = socketChannel.pipeline();
		pipeline.addLast(new MessageDecoder(1024, Unpooled.copiedBuffer(MessageConfig.INSTANCE.getHead().getBytes()), Unpooled.copiedBuffer(MessageConfig.INSTANCE.getTail().getBytes())));
		pipeline.addLast(new IdleStateHandler(TIME_OUT_SECONDS, TIME_OUT_SECONDS, TIME_OUT_SECONDS));
		pipeline.addLast(new ClientEventHandler());
	}
}
